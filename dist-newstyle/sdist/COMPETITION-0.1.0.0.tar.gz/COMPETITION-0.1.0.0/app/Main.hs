module Main where

import Graphics.Gloss
import Data.Complex
import Control.Parallel.Strategies (parMap, rpar)

-- Convert integral types to floating-point values
fnt :: (Integral a, Num b) => a -> b
fnt = fromIntegral

-- Core Mandelbrot iteration function
mandelbrotIter :: Complex Double -> Complex Double -> Int -> Int
mandelbrotIter c z count
    | count >= maxIter = maxIter
    | magnitude z > 2  = count
    | otherwise        = mandelbrotIter (z*z+c) (c) (count + 1)

-- Calculate iterations for a point
mandelbrot :: Double -> Double -> Int
mandelbrot x y = mandelbrotIter (x :+ y) (0 :+ 0) 0

-- Convert iterations to color
colorMapping :: Int -> Color
colorMapping i
    | i == maxIter = black
    | otherwise    = makeColorI (i * 255 `div` maxIter) 0 (255 - i * 255 `div` maxIter) 255

-- Generate the Mandelbrot set image
mandelbrotImage :: Int -> Int -> Picture
mandelbrotImage width height =
    Pictures $ parMap rpar createPixel [(x, y) | x <- [0..width-1], y <- [0..height-1]]
  where
    createPixel (x, y) = 
        translate (fnt x - fnt width / 2) (fnt y - fnt height / 2) $ 
        color (colorMapping (mandelbrot (scaledX x) (scaledY y))) 
        (rectangleSolid 1 1)
    scaledX x = (fnt x / fnt width - 0.5) * 3.5
    scaledY y = (fnt y / fnt height - 0.5) * 3.0

-- Constants
maxIter :: Int
maxIter = 100

screenWidth, screenHeight :: Int
screenWidth = 800
screenHeight = 800

main :: IO ()
main = display window background (mandelbrotImage screenWidth screenHeight)
  where
    window = InWindow "Mandelbrot Set" (screenWidth, screenHeight) (100, 100)
    background = black